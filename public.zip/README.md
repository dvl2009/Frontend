# Info
Written by Mark
This repo is only for reference. It demostrates (1) how to call the API Gateway endpoints and (2) how to integrate AWS Cognito for login/signup in React.
We won't be using the code here for the actual frontend.
